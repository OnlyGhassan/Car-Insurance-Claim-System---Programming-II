/*
Name : Ghassan Alghamdi
ID : 2144200
Section : EE
 */
public class Car {

    private String CarPlateNo;
    private String CarType;
    private String Brand;
    private String CarModel;
    private String CarColor;
    private int BuiltYear;

    public Car(String CarPlateNo, String CarType, String Brand, String CarModel, String CarColor, int BuiltYear) {
        this.CarPlateNo = CarPlateNo;
        this.CarType = CarType;
        this.Brand = Brand;
        this.CarModel = CarModel;
        this.CarColor = CarColor;
        this.BuiltYear = BuiltYear;
    }
//---------------------------------------------------------------------------------------------

    public String getCarPlateNo() {
        return CarPlateNo;
    }
//---------------------------------------------------------------------------------------------

    public void setCarPlateNo(String CarPlateNo) {
        this.CarPlateNo = CarPlateNo;
    }
//---------------------------------------------------------------------------------------------

    public String getCarType() {
        return CarType;
    }
//---------------------------------------------------------------------------------------------

    public void setCarType(String CarType) {
        this.CarType = CarType;
    }
//---------------------------------------------------------------------------------------------

    public String getBrand() {
        return Brand;
    }
//---------------------------------------------------------------------------------------------

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }
//---------------------------------------------------------------------------------------------

    public String getCarModel() {
        return CarModel;
    }
//---------------------------------------------------------------------------------------------

    public void setCarModel(String CarModel) {
        this.CarModel = CarModel;
    }
//---------------------------------------------------------------------------------------------

    public String getCarColor() {
        return CarColor;
    }
//---------------------------------------------------------------------------------------------

    public void setCarColor(String CarColor) {
        this.CarColor = CarColor;
    }
//---------------------------------------------------------------------------------------------

    public int getBuiltYear() {
        return BuiltYear;
    }
//---------------------------------------------------------------------------------------------

    public void setBuiltYear(int BuiltYear) {
        this.BuiltYear = BuiltYear;
    }
//---------------------------------------------------------------------------------------------

    @Override
    public String toString() {
        // formating the output
        return String.format("%-15s%-17s%-17s%-17s%-17s%-17s", CarPlateNo, " Type: "
                + CarType, " Brand: " + Brand, " Model: " + CarModel,
                " Color: " + CarColor, " Mfg. Year: " + BuiltYear);
    }

}
