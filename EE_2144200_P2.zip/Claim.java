/*
Name : Ghassan Alghamdi
ID : 2144200
Section : EE
 */
import java.util.Date;

public class Claim {
// 3 Aggregation 
    private long ClaimNo;
    private InsuranceCoverage insuranceCoverageCode;
    private Car carNo;
    private Owner nationalID;
    private String location;
    private Date claimDate;
    private boolean hasPremium;
    private boolean hasSpecialOffer;
    

    public Claim(long ClaimNo, InsuranceCoverage insuranceCoverageCode, Car carNo, Owner nationalID, String location,
            Date claimDate, boolean hasPremium, boolean hasSpecialOffer) {
        this.ClaimNo = ClaimNo;
        this.insuranceCoverageCode = insuranceCoverageCode;
        this.carNo = carNo;
        this.nationalID = nationalID;
        this.location = location;
        this.claimDate = claimDate;
        this.hasPremium = hasPremium;
        this.hasSpecialOffer = hasSpecialOffer;
    }
//---------------------------------------------------------------------------------------------

    public long getClaimNo() {
        return ClaimNo;
    }
//---------------------------------------------------------------------------------------------

    public void setClaimNo(long ClaimNo) {
        this.ClaimNo = ClaimNo;
    }
//---------------------------------------------------------------------------------------------

    public String getLocation() {
        return location;
    }
//---------------------------------------------------------------------------------------------

    public void setLocation(String location) {
        this.location = location;
    }
//---------------------------------------------------------------------------------------------

    public Date getClailmDate() {
        return claimDate;
    }
//---------------------------------------------------------------------------------------------

    public void setClailmDate(Date clailmDate) {
        this.claimDate = clailmDate;
    }
//---------------------------------------------------------------------------------------------

    public boolean getHasPremiumInsurance() {
        return hasPremium;
    }
//---------------------------------------------------------------------------------------------

    public void setHasPremiumInsurance(boolean hasPremium) {
        this.hasPremium = hasPremium;
    }
//---------------------------------------------------------------------------------------------

    public boolean getHasSpecialOffer() {
        return hasSpecialOffer;
    }
//---------------------------------------------------------------------------------------------

    public void setHasSpecialOffer(boolean hasSpecialOffer) {
        this.hasSpecialOffer = hasSpecialOffer;
    }
//---------------------------------------------------------------------------------------------

    public InsuranceCoverage getInsuranceCoverageCode() {
        return insuranceCoverageCode;
    }
//---------------------------------------------------------------------------------------------

    public void setInsuranceCoverageCode(InsuranceCoverage insuranceCoverageCode) {
        this.insuranceCoverageCode = insuranceCoverageCode;
    }
//---------------------------------------------------------------------------------------------

    public Car getCarNo() {
        return carNo;
    }
//---------------------------------------------------------------------------------------------

    public void setCarNo(Car carNo) {
        this.carNo = carNo;
    }
//---------------------------------------------------------------------------------------------

    public Owner getNationalID() {
        return nationalID;
    }
//---------------------------------------------------------------------------------------------

   
    public void setNationalID(Owner nationalID) {
        this.nationalID = nationalID;
    }
//---------------------------------------------------------------------------------------------

    public double CalculateFinalClaimAmount() {
        //adding extra amount if need so, then return total amount
        double totalAmount = 350;
        if (!getHasPremiumInsurance()) {
            totalAmount -= 200;
        }
        if (!getHasSpecialOffer()) {
            totalAmount -= 100;
        }

        if ((new Integer(new Date().getYear() + 1900)) - new Integer(nationalID.getDob().getYear()) < 60) {
            totalAmount -= 50;
        }

        return totalAmount;
    }
}
