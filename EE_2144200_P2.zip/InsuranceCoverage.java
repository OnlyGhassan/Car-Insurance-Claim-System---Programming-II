/*
Name : Ghassan Alghamdi
ID : 2144200
Section : EE
 */
public class InsuranceCoverage {

    private int insuranceCoverageCode;
    private String description;
    private double amount;

    public InsuranceCoverage(int insuranceCoverageCode, String description, double amount) {
        this.insuranceCoverageCode = insuranceCoverageCode;
        this.description = description.replace("_"," ");
        this.amount = amount;
    }
//---------------------------------------------------------------------------------------------

    public int getInsuranceCoverageCode() {
        return insuranceCoverageCode;
    }
//---------------------------------------------------------------------------------------------

    public void setInsuranceCoverageCode(int insuranceCoverageCode) {
        this.insuranceCoverageCode = insuranceCoverageCode;
    }
//---------------------------------------------------------------------------------------------

    public String getDescription() {
        return description;
    }
//---------------------------------------------------------------------------------------------

    public void setDescription(String description) {
        this.description = description;
    }
//---------------------------------------------------------------------------------------------

    public double getAmount() {
        return amount;
    }
//---------------------------------------------------------------------------------------------

    public void setAmount(double amount) {
        this.amount = amount;
    }
//---------------------------------------------------------------------------------------------

    @Override
    public String toString() {
        return insuranceCoverageCode + "\tInsuranceCoverage description: " + description;
    }

}
