/*
Name : Ghassan Alghamdi
ID : 2144200
Section : EE
 */
import java.text.*;
import java.io.*;
import java.util.*;

public class ProcessClaim {

    public static void main(String[] args) throws FileNotFoundException, ParseException {
        File inputCICS = new File("C:\\Users\\HP\\Documents\\NetBeansProjects\\ProcessClaim\\src\\inputCICS.txt");
        if (!inputCICS.exists()) {
            System.out.println("File " + inputCICS.getName() + " doesn't exist");
            System.exit(0);
        }

        Scanner readCICS = new Scanner(inputCICS);
// creating 3 object array
        Car[] car = new Car[readCICS.nextInt()];
        Owner[] owner = new Owner[readCICS.nextInt()];
        InsuranceCoverage[] insuranceCoverage = new InsuranceCoverage[readCICS.nextInt()];
// loop to creat objects for car-owner-insuranceCoverage arrays
        String command;
        int w = 0, e = 0, r = 0;
        do {
            //cheaking the commands
            command = readCICS.next();
            switch (command) {
                case "AddCar":
                    car[w] = getCar(readCICS);

                    w++;
                    break;
                case "AddOwner":
                    owner[e] = getOwner(readCICS);
                    e++;
                    break;
                case "AddInsuranceCoverage":
                    insuranceCoverage[r] = getInsuranceCoverage(readCICS);
                    r++;
                    break;
            }
        } while (!command.equals("Quit"));
        readCICS.close();

        File CICS = new File("C:\\Users\\HP\\Documents\\NetBeansProjects\\ProcessClaim\\src\\CICSDatabase.txt");
        PrintWriter outputCICS = new PrintWriter(CICS);
// printing the first file
        outputCICS.println("--------------- Welcome to CICS  Database ---------------\n");
        outputCICS.println();
        for (int s = 0; s < car.length; s++) {
            outputCICS.println("\tCar No : " + car[s].toString());
            outputCICS.println("------------------------------------------------------");
            outputCICS.println();
        }
        for (int a = 0; a < insuranceCoverage.length; a++) {
            outputCICS.println("\tInsuranceCoverage Code: " + insuranceCoverage[a].toString());
            outputCICS.println("------------------------------------------------------");
            outputCICS.println();
        }
        for (int d = 0; d < owner.length; d++) {
            outputCICS.println("\tOwner ID: " + owner[d].toString());
            outputCICS.println("------------------------------------------------------");
            outputCICS.println();
        }
        outputCICS.flush();
        outputCICS.close();

        File inputClaims = new File("C:\\Users\\HP\\Documents\\NetBeansProjects\\ProcessClaim\\src\\inputClaims.txt");
        if (!inputClaims.exists()) {
            System.out.println("File " + inputClaims.getName() + " doesn't exist");
            System.exit(0);
        }

        Scanner inputCl = new Scanner(inputClaims);
        Claim[] claim = new Claim[inputCl.nextInt()];
//loop to creat objects for claim array
        int b = 0;
        do {
            command = inputCl.next();
            if (command.equals("ProcessClaim")) {
                claim[b] = GenerateClaim(inputCl, insuranceCoverage, car, owner);
                
                b++;

            }
        } while (command.equals("ProcessClaim"));
        inputCl.close();

        File outputClaims = new File("C:\\Users\\HP\\Documents\\NetBeansProjects\\ProcessClaim\\src\\ClaimInvoices.txt");
        PrintWriter outputC = new PrintWriter(outputClaims);
// calling print method for claim details
        PrintClaim(claim, outputC);
// calling print method for number of claim per owner
        NomOfInsuranceCoveragePerOwner(owner, claim, outputC);

        outputC.flush();
        outputC.close();

    }
//---------------------------------------------------------------------------------------------

    private static Claim GenerateClaim(Scanner inputCl, InsuranceCoverage[] insuranceCoverage, Car[] car, Owner[] owner) throws ParseException {
        long InvoiceNo = System.currentTimeMillis();
        //calling the associating method
        InsuranceCoverage IC = searchInsuranceCoverage(insuranceCoverage, inputCl.next());
        Car carno = searchCar(car, inputCl.next());
        Owner ownerID = searchOwner(owner, inputCl.next());

        String location = inputCl.next();
        //reading the date as a string
        String date = inputCl.next() + "-" + inputCl.next() + "-" + inputCl.next();

        boolean Premium = inputCl.nextBoolean();
        //formating and converting the date
        SimpleDateFormat sdfdate = new SimpleDateFormat("yyyy-MM-dd");
        Date claimdate = sdfdate.parse(date);
        boolean offer = inputCl.nextBoolean();
// returing full constructor to creat claim object
        return new Claim(InvoiceNo, IC, carno, ownerID, location, claimdate, Premium, offer);

    }
//---------------------------------------------------------------------------------------------

    public static void PrintClaim(Claim[] claim, PrintWriter writerC) {
//printing the seconde file
        SimpleDateFormat s1 = new SimpleDateFormat("yyyy-dd-MM");

        writerC.println("--------------- Welcome to Traffic Claim System ---------------\n\n");

        for (int w = 0; w < claim.length; w++) {
//formating the date and converte it to a string to print it
            String dob = s1.format(claim[w].getClailmDate());
            double au = claim[w].getInsuranceCoverageCode().getAmount();
            //calling the extra amount method
            double fc = claim[w].CalculateFinalClaimAmount();

            writerC.printf("Invoice No.  " + claim[w].getClaimNo() + "\n\n"
                    + "Insurance Coverage Details\n"
                    + "\tInsurance Coverage Code: " + claim[w].getInsuranceCoverageCode().getInsuranceCoverageCode() + "\n"
                    + "\tInsurance Coverage Description: " + claim[w].getInsuranceCoverageCode().getDescription() + "\n"
                    + "\tInsurance Coverage Penalty: " + claim[w].getInsuranceCoverageCode().getAmount() + "\n\n"
                    + "Car Details\n"
                    + "\tNumber Plate: " + claim[w].getCarNo().getCarPlateNo() + "\n"
                    + "\tType: " + claim[w].getCarNo().getCarType() + "\n"
                    + "\tBrand: " + claim[w].getCarNo().getBrand() + "\n"
                    + "\tModel: " + claim[w].getCarNo().getCarModel() + "\n"
                    + "\tColor: " + claim[w].getCarNo().getCarColor() + "\n"
                    + "\tBuilt Year: " + claim[w].getCarNo().getBuiltYear() + "\n\n"
                    + "Owner Details\n"
                    + "\tNational Id: " + claim[w].getNationalID().getNationalID() + "\n"
                    + "\tFull Name: " + claim[w].getNationalID().getFirst_name() + " "
                    + claim[w].getNationalID().getLast_name() + "\n\n"
                    + "Claim Detail\n"
                    + "\tDate: " + dob + "\n"
                    + "\tLocation: " + claim[w].getLocation() + "\n\n");

            writerC.print("Total Amount: " + (au + fc) + "\n"
                    + "â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â"
                    + "”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€\n");

        }

    }
//---------------------------------------------------------------------------------------------

    public static void NomOfInsuranceCoveragePerOwner(Owner[] owner, Claim[] claim, PrintWriter output) {
        //printing number of claims per ownre
        output.println("--------Total claim(s) by owner--------\n");
        output.println("Owner ID\t\tOwner Name\t    Total Claim(s)\n");
        for (int y = 0; y < owner.length; y++) {
            int h = 0;
            for (int s = 0; s < claim.length; s++) {
                // cheaking the claims then add it to the h 
                if (owner[y].getNationalID().equals(claim[s].getNationalID().getNationalID())) {
                    h++;
                }
            }
            output.printf("%20s" + "\t\t\t" + h, owner[y].getNationalID() + "\t\t" + owner[y].getFirst_name() + " " + owner[y].getLast_name());
            output.println();
        }
    }
//---------------------------------------------------------------------------------------------

    public static Car searchCar(Car[] car, String carNo) {
//searching for the right car-object then return it
        for (int w = 0; w < car.length; w++) {
            if (carNo.equals(car[w].getCarPlateNo())) {
                return car[w];
            }
        }
        return null;
    }
//---------------------------------------------------------------------------------------------

    private static Car getCar(Scanner read) {
        // returing full constructor to creat car object
        return new Car(read.next(), read.next(), read.next(), read.next(), read.next(), read.nextInt());
    }
//---------------------------------------------------------------------------------------------

    private static Owner getOwner(Scanner read) {
        return new Owner(read.next(), read.next(), read.next(), new Date(read.nextInt(), read.nextInt(), read.nextInt()));
    }
//---------------------------------------------------------------------------------------------

    public static Owner searchOwner(Owner[] owner, String ownerID) {
        for (int w = 0; w < owner.length; w++) {
            if (ownerID.equals(owner[w].getNationalID())) {
                return owner[w];
            }
        }
        return null;
    }
//---------------------------------------------------------------------------------------------

    private static InsuranceCoverage getInsuranceCoverage(Scanner read) {
        return new InsuranceCoverage(read.nextInt(), read.next(), read.nextDouble());
    }
//---------------------------------------------------------------------------------------------

    public static InsuranceCoverage searchInsuranceCoverage(InsuranceCoverage[] insuranceCoverage, String code) {
        for (int w = 0; w < insuranceCoverage.length; w++) {
            if (code.equals(insuranceCoverage[w].getInsuranceCoverageCode() + "")) {
                return insuranceCoverage[w];
            }
        }
        return null;
    }
}
